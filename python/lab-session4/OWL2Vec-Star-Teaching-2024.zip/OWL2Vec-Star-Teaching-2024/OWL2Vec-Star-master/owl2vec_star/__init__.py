"""Top-level package for OWL2Vec-Star."""

__author__ = """Jiaoyan Chen"""
__email__ = 'chen00217@gmail.com'
__version__ = '0.2.0'
